package com.maiji.magkareble40;

/**
* @author xqx
* @email djlxqx@163.com
* blog:http://www.cnblogs.com/xqxacm/
* createAt 2017/9/6
* description: 用于获取到数据之后刷新界面 显示数据
*/


public class RefreshDatas {

    public RefreshDatas() {
    }



}
